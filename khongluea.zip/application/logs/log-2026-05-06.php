<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-05-06 05:42:22 --> 404 Page Not Found: /index
ERROR - 2026-05-06 05:43:25 --> 404 Page Not Found: admin/Login/index
ERROR - 2026-05-06 05:44:37 --> 404 Page Not Found: /index
