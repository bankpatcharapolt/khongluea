<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-05-05 14:57:03 --> 404 Page Not Found: /index
ERROR - 2026-05-05 14:57:03 --> Severity: Warning --> include(application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 14:57:03 --> Severity: Warning --> include(): Failed opening 'application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 14:57:14 --> 404 Page Not Found: /index
ERROR - 2026-05-05 14:57:14 --> Severity: Warning --> include(application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 14:57:14 --> Severity: Warning --> include(): Failed opening 'application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 14:58:05 --> 404 Page Not Found: /index
ERROR - 2026-05-05 14:58:05 --> Severity: Warning --> include(application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 14:58:05 --> Severity: Warning --> include(): Failed opening 'application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 15:00:08 --> 404 Page Not Found: /index
ERROR - 2026-05-05 15:00:08 --> Severity: Warning --> include(application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 15:00:08 --> Severity: Warning --> include(): Failed opening 'application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 15:00:57 --> 404 Page Not Found: /index
ERROR - 2026-05-05 15:00:57 --> Severity: Warning --> include(application\views\errors\html\error_404.php): failed to open stream: No such file or directory C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 15:00:57 --> Severity: Warning --> include(): Failed opening 'application\views\errors\html\error_404.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\khongluea\system\core\Exceptions.php 183
ERROR - 2026-05-05 10:01:53 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:03:02 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:03:44 --> 404 Page Not Found: Home/index
ERROR - 2026-05-05 10:04:55 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:07:39 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:09:38 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:10:18 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:11:13 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:11:29 --> 404 Page Not Found: frontend//index
ERROR - 2026-05-05 10:11:32 --> 404 Page Not Found: Assets/js
ERROR - 2026-05-05 10:11:32 --> 404 Page Not Found: Assets/css
ERROR - 2026-05-05 10:11:36 --> 404 Page Not Found: Assets/js
ERROR - 2026-05-05 10:11:36 --> 404 Page Not Found: Assets/css
ERROR - 2026-05-05 10:11:45 --> 404 Page Not Found: Assets/css
ERROR - 2026-05-05 10:11:45 --> 404 Page Not Found: Assets/js
ERROR - 2026-05-05 10:12:57 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:13:03 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:13:44 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:15:19 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:16:08 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:16:18 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:16:21 --> 404 Page Not Found: Home/index
ERROR - 2026-05-05 10:17:32 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:18:08 --> 404 Page Not Found: admin/Home/index
ERROR - 2026-05-05 10:18:12 --> 404 Page Not Found: admin/Home/index
ERROR - 2026-05-05 10:18:15 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:20:58 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::bind() C:\xampp\htdocs\khongluea\application\models\Conversation_model.php 48
ERROR - 2026-05-05 10:20:58 --> Severity: Warning --> include(C:\xampp\htdocs\khongluea\application\views\errors\html\error_exception.php): failed to open stream: No such file or directory C:\xampp\htdocs\khongluea\system\core\Exceptions.php 220
ERROR - 2026-05-05 10:20:58 --> Severity: Warning --> include(): Failed opening 'C:\xampp\htdocs\khongluea\application\views\errors\html\error_exception.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\khongluea\system\core\Exceptions.php 220
ERROR - 2026-05-05 10:21:08 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:23:10 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:23:14 --> 404 Page Not Found: /index
ERROR - 2026-05-05 10:23:22 --> 404 Page Not Found: /index
